import { LightningElement, wire,api } from 'lwc';

import fetchquotes from '@salesforce/apex/quoteSearchController.getQuotes';


export default class QuoteSearchResult extends LightningElement {

  /*  quotes = [
        {'Id':1,'Quote_pic__c':'/resource/quotetopics/topics/women/Q20.jpg','AuthorName': 'B. R. Ambedkar'},
        {'Id':2,'Quote_pic__c':'/resource/quotetopics/topics/smile/Q7.jpg','AuthorName': 'Balu'},
        {'Id':3,'Quote_pic__c':'/resource/quotetopics/topics/truth/Q11.jpg','AuthorName': 'VBS'},
        {'Id':4,'Quote_pic__c':'/resource/quotetopics/topics/funny/Q18.jpg','AuthorName': 'Nag'},
        {'Id':5,'Quote_pic__c':'/resource/quotetopics/topics/motivation/Q6.jpg','AuthorName': 'ABCD'},

    ];*/
    quotes;

    @api selectedQuoteTopicId;

    hasQuotesfound;

    @wire(fetchquotes,{quoteTopicId:'$selectedQuoteTopicId'})
    processOutput({data,error})
    {
        if(data)
        {
            this.quotes =data;
            if(data.length>0)
            {
                this.hasQuotesfound=true;
            }
            else
            {
                this.hasQuotesfound= false;
            }

            
        }
        else if(error)
        {
            console.group('Something went wrong!!!'+ error.body.message);
        }
    }
}