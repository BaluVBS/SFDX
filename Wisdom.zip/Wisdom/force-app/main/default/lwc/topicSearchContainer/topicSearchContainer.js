import { LightningElement } from 'lwc';

export default class TopicSearchContainer extends LightningElement {

    quoteTopicId='';
    quoueTopicSelectHandler(event)
    {
        this.quoteTopicId = event.detail;
        console.log('value of selected quote topic id in parent is::'+this.quoteTopicId);
    }
}