import { LightningElement } from 'lwc';

export default class SubscribeQuote extends LightningElement {}