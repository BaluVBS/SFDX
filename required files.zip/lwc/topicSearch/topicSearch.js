import { LightningElement, wire } from 'lwc';
import fetchquoteTopics from '@salesforce/apex/topicSearchController.getQuoteTopics';
import {NavigationMixin} from 'lightning/navigation';

export default class TopicSearch extends NavigationMixin(LightningElement) {
    
    value = 'All Topics';
    
    /*options = [
        {label:'All Topics', value:'All Topics'},
        {label:'Motivation', value:'Motivation'},
        {label:'Smile', value:'Smile'},
    ];*/

    quoteTypes;
    
    @wire(fetchquoteTopics)
    processOutput({data,error})
    {
        if(data)
        {
            this.quoteTypes = [{value:'',label:'All Topics'}];
            data.forEach(element =>{

                const quoteType = {};
                quoteType.label = element.Name;
                quoteType.value = element.Id;
                this.quoteTypes.push(quoteType);
            });
        }
        else if(error)
        {
            console.group('Something went wrong!!!'+ error.body.message);
        }
    }
    handleClick(event)
    {   
        console.log('Inside newbutton');
        //alert('alert box - New button');
        const pageToNavigate = {
            type:'standard__objectPage',
            attributes:{
                objectApiName: 'Quote_Topic__c',
                actionName:'new'
            }
        }
        this[NavigationMixin.Navigate](pageToNavigate);
    }
    handleChange(event)
    {
        const selectedTopicId = event.detail.value;
        //alert(selectedTopicId);
        const quoteTopicChangeEvent = new CustomEvent('quotetypeselect',{detail: selectedTopicId});
        this.dispatchEvent(quoteTopicChangeEvent);
    }
}
