import { LightningElement } from 'lwc';

export default class QuoteDetail extends LightningElement {}