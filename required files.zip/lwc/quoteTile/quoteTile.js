import { LightningElement, api } from 'lwc';
export default class QuoteTile extends LightningElement {

   /* imgData = {

        'Quote_pic__c':'/resource/quotetopics/topics/women/Q20.jpg','AuthorName': 'B. R. Ambedkar'

    }*/
    @api quote;

    connectedCallback()
    {
        console.log("quote::"+JSON.stringify(this.quote));
    }
    handleQuoteClick()
    {
        alert('I just Clicked a quote !!!');
        console.log('Value of quote property::'+this.quote);
        console.log(`Value of quote property is ${this.quote}`);

    }
}