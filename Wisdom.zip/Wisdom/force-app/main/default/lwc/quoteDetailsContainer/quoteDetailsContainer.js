import { LightningElement } from 'lwc';

export default class QuoteDetailsContainer extends LightningElement {}