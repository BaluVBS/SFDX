import { LightningElement } from 'lwc';

export default class AuthorNotableWork extends LightningElement {}