import { LightningElement } from 'lwc';

export default class AddAuthorNotableWork extends LightningElement {}